<?php 
$host="localhost";
$user="root";
$pass="";
$dbname="lib";
try {
	$dbc = new PDO ("mysql:host=$host;dbname=$dbname",$user,$pass);

}catch(PDOExeption $e){
		die('Database Got problem in : '.$e->getMessage());
}

 ?>