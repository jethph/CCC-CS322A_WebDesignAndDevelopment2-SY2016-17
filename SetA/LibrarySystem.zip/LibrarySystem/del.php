<?php
  include("db.php");  

	$id =$_REQUEST['BookID'];
	
	
	// sending query
	$query= $dbc->query("DELETE FROM books WHERE BookID = '$id' ");
	$query->execute();
	header("Location: index.php");
?>