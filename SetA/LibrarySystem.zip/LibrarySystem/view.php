<?php
require("db.php");
$id =$_REQUEST['BookID'];


$query = $dbc->query("SELECT * FROM books WHERE BookID = '$id'");
$query->execute();
$query=$query->fetch(PDO::FETCH_ASSOC);

				$Title=$query['Title'] ;
				$Author= $query['Author'] ;					
				$PublisherName=$query['PublisherName'] ;
				$CopyrightYear=$query['CopyrightYear'] ;

if(isset($_POST['save'])){	
	$title_save = $_POST['title'];
	$author_save = $_POST['author'];
	$name_save = $_POST['name'];
	$copy_save = $_POST['copy'];

		$update = $dbc->query("UPDATE books SET Title ='$title_save', Author ='$author_save',
		 PublisherName ='$name_save',CopyrightYear ='$copy_save' WHERE BookID = '$id'");
			$update->execute();
			if($update){
					echo "<script>alert('DATA SUCCESFULY UPDATED !');
					self.location='index.php'</script>";
			}
		
}

?>
<!DOCTYPE html >
<html >
<head>
<link href="css/view.css" type="text/css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
#position{
                background-image: url("images/bg2.jpg");
	            background-repeat: no-repeat;}
 </style>
<title>Untitled Document</title>
</head>

<body>
<div id="position">
<img src="images/Capture.jpg">
<fieldset>
<form method="post">
<table>
	<tr>
		<td >Title:</td>
		<td><input type="text" name="title" value="<?php echo $Title ?>"/></td>
	</tr>
	<tr>
		<td>Author</td>
		<td><input type="text" name="author" value="<?php echo $Author ?>"/></td>
	</tr>
	<tr>
		<td>Publisher Name</td>
		<td><input type="text" name="name" value="<?php echo $PublisherName ?>"/></td>
	</tr>
	<tr>
		<td>Copyright Year</td>
		<td><input type="text" name="copy" value="<?php echo $CopyrightYear ?>"/></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="save" value="save" /></td>
	</tr>
</table>
</fieldset>
</div>
</body>
</html>