<?php require 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
<link href="css/index.css" type="text/css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <style type="text/css">
#position{
        background-image: url("images/bg2.jpg");
	    background-repeat: no-repeat;}
</style>
<title>Books</title>
</head>
<body>
<div id="position">
<img src="images/Capture.jpg">
<fieldset>
<form method="post">
<table >
<tr>
		<td class="a">Title: </td>
		<td><input type="text" name="title" placeholder="title" /></td>
	</tr>
	<tr>
		<td class="b">Author: </td>
		<td><input type="text" name="author" placeholder="Author" /></td>
	</tr>
	<tr>
		<td class="c">Publisher Name: </td>
		<td><input type="text" name="name" placeholder="Publisher Name" /></td>
	</tr>
	<tr>
		<td class="d">Copyright Year: </td>
		<td><input type="text" name="copy" placeholder="Copyright Year" /></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" name="submit" value="ADD" /></td>
	</tr>
</table>
<?php
if (isset($_POST['submit']))
	{	   
			 		$title=$_POST['title'] ;
					$author= $_POST['author'] ;					
					$name=$_POST['name'] ;
					$copy=$_POST['copy'] ;
												
					$query = $dbc->prepare("INSERT INTO books (title,Author,PublisherName,CopyrightYear) 
						VALUES (:Title,:Author,:PublisherName,:CopyrightYear)");
					$query->execute(array(':Title'=>$title,
								          ':Author'=>$author,
									      ':PublisherName'=>$name,
									      ':CopyrightYear'=>$copy));
				
	        }
?>
</form>
<table cellpadding="0" width="500" border="1" cellspacing="0">
	
			<?php
				
			$results=$dbc->query("SELECT * FROM books");
			$results->execute();
			$results = $results->fetchAll(PDO::FETCH_ASSOC);
			foreach ($results as $result){
				
				$id = $result['BookID'];	
				echo "<tr align='center'>";	
				echo"<td><font color='black'>" .$result['BookID']."</font></td>";
				echo"<td width='100'><font color='black'>" .$result['Title']."</font></td>";
				echo"<td width='100'><font color='black'>". $result['Author']. "</font></td>";
				echo"<td width='100'><font color='black'>". $result['PublisherName']. "</font></td>";
				echo"<td><font color='black'>". $result['CopyrightYear']. "</font></td>";	
				echo"<td> <a href ='view.php?BookID=$id'> Edit</a>";
				echo"<td> <a href ='del.php?BookID=$id'><center>Delete</center></a>";
				echo "</tr>";
				
			}
	
			?>
</table>
</fieldset>
</div>
</body>

</html>
